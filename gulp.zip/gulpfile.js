'use strict';

var del = require('del');
var gulp = require('gulp');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var useref = require('gulp-useref');
var gulpif = require('gulp-if');
var cssnano = require('gulp-cssnano');
var runsequence = require('run-sequence');
var browsersync = require('browser-sync').create();

var appdir = './app'
var filesjs = "./app/js/*.js";
var fonts = "./app/fonts/*.ttf";
var images = "./app/images/*.gif";
var scss = "./app/scss/*.scss";
var html = "./app/*.html";
var css = "./app/css/*.css";
var cssdir = "./app/css";


var dist = './dist'
var distfonts = dist + "/fonts";
var distimages = dist + "/images";
var disthtml = dist + "/*.html";
var distcss = dist +"/css/*.css";
var distjs = dist +"/js/*.js";



gulp.task('scss', function() {
  return gulp.src(scss)
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest(cssdir));
});

gulp.task('watch', function() {
  gulp.watch(filesjs, ['minify']);
  gulp.watch(css, ['minify']);
  gulp.watch(html, ['minify']);
});

gulp.task('reload', function() {
  gulp.watch(distjs).on('change', browsersync.reload);
  gulp.watch(distcss).on('change', browsersync.reload);
  gulp.watch(disthtml).on('change', browsersync.reload);
});

gulp.task('browsersync', function() {
  browsersync.init({
    server: {
      baseDir: dist
    }
  });
});

gulp.task('build-clean', function() {
  return del.sync(dist + "/**")
});

gulp.task('fonts', function() {
  return gulp.src(fonts)
    .pipe(gulp.dest(distfonts));
});

gulp.task('images', function() {
  return gulp.src(images)
    .pipe(gulp.dest(distimages));
});

gulp.task('minify', function(){
  return gulp.src(html)
  .pipe(useref())
  .pipe(gulpif('*.js', uglify()))
  .pipe(gulpif('*.css', cssnano()))
  .pipe(gulp.dest(dist))
});

gulp.task('build', function(cb) {
  runsequence('build-clean', ['fonts', 'images'], 'scss', 'minify', cb);
});

gulp.task('default', ['browsersync', 'watch','reload']);
